# TECHHVEN NVR CCTV — Termux

## Install
1. Extract this ZIP into Android Downloads.
2. In Termux run:

```bash
pkg update -y && pkg upgrade -y
pkg install python ffmpeg -y
python -m pip install --upgrade pip
pip install flask requests
termux-setup-storage
cd ~/storage/downloads/TECHHVEN_NVR_CCTV
chmod +x start.sh
./start.sh
```

If extracted to another folder name, `cd` into that exact folder.

3. Open Chrome on the same phone: http://127.0.0.1:8765
Keep Termux open while viewing.

## NVR setup
- Phone and NVR must share the same LAN.
- Enable ONVIF on the recorder.
- Use a valid ONVIF account with live-view permission.
- Discover via ONVIF multicast or enter the NVR IP manually.
- Select an ONVIF profile to request its RTSP stream and play through FFmpeg HLS.

## Limitations and safety
- Prama/CP Plus compatibility depends on exact model and firmware exposing standard ONVIF Media/RTSP.
- Up to 64 ONVIF profiles are displayed, not necessarily 64 physical cameras.
- Start with one stream. 64 concurrent FFmpeg processes are unsuitable for most phones.
- Wi-Fi isolation, VLANs or multicast filtering can block discovery.
- Some codecs may not play in the browser.
- Credentials stay in RAM and are not saved to disk.
- Server binds only to 127.0.0.1; do not expose it publicly.
- No password guessing, extraction or bypassing. Use only authorized equipment.
