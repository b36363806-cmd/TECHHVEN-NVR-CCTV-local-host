
import re, time, uuid, socket, subprocess, shutil
from pathlib import Path
from urllib.parse import urlparse, urlunparse, quote
import xml.etree.ElementTree as ET
import requests
from requests.auth import HTTPDigestAuth, HTTPBasicAuth
from flask import Flask, request, jsonify, render_template, send_from_directory

BASE=Path(__file__).resolve().parent
HLS=BASE/"hls"; HLS.mkdir(exist_ok=True)
app=Flask(__name__); DEVICES={}; STREAMS={}
ENV="http://www.w3.org/2003/05/soap-envelope"
WSA="http://www.w3.org/2005/08/addressing"
DEV="http://www.onvif.org/ver10/device/wsdl"
MED="http://www.onvif.org/ver10/media/wsdl"

def lname(t): return t.split("}",1)[-1]
def txt(root,key):
    for e in root.iter():
        if lname(e.tag)==key and e.text: return e.text.strip()
    return ""
def envelope(op,ns,inner=""):
    mid="uuid:"+str(uuid.uuid4())
    return f'''<?xml version="1.0"?>
<s:Envelope xmlns:s="{ENV}" xmlns:a="{WSA}">
<s:Header><a:MessageID>{mid}</a:MessageID><a:Action>{ns}/{op}</a:Action></s:Header>
<s:Body><{op} xmlns="{ns}">{inner}</{op}></s:Body></s:Envelope>'''
def soap(url,body,user,pwd):
    for auth in (HTTPDigestAuth(user,pwd),HTTPBasicAuth(user,pwd)):
        try:
            r=requests.post(url,data=body.encode(),headers={"Content-Type":"application/soap+xml"},auth=auth,timeout=8,verify=False)
            if r.status_code==200:return ET.fromstring(r.content)
        except Exception: pass
    raise RuntimeError("ONVIF login/request failed. Check IP, ONVIF setting, account and service URL.")
def discover():
    msg=f'''<?xml version="1.0"?>
<e:Envelope xmlns:e="{ENV}" xmlns:w="{WSA}" xmlns:d="http://schemas.xmlsoap.org/ws/2005/04/discovery" xmlns:dn="http://www.onvif.org/ver10/network/wsdl">
<e:Header><w:MessageID>uuid:{uuid.uuid4()}</w:MessageID><w:To>urn:schemas-xmlsoap-org:ws:2005:04:discovery</w:To>
<w:Action>http://schemas.xmlsoap.org/ws/2005/04/discovery/Probe</w:Action></e:Header>
<e:Body><d:Probe><d:Types>dn:NetworkVideoTransmitter</d:Types></d:Probe></e:Body></e:Envelope>'''
    found={}; s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM,socket.IPPROTO_UDP)
    try:
        s.settimeout(.6); s.setsockopt(socket.IPPROTO_IP,socket.IP_MULTICAST_TTL,2)
        s.sendto(msg.encode(),("239.255.255.250",3702)); end=time.time()+4
        while time.time()<end:
            try: data,addr=s.recvfrom(65535)
            except socket.timeout: continue
            try:
                x=ET.fromstring(data); xa=txt(x,"XAddrs")
                found[addr[0]]={"ip":addr[0],"xaddr":xa.split()[0] if xa else ""}
            except ET.ParseError: pass
    finally:s.close()
    return list(found.values())
def connect(ip,user,pwd,xaddr):
    if not re.fullmatch(r"[0-9a-fA-F:.]+",ip): raise ValueError("Enter a valid NVR LAN IP.")
    p=urlparse(xaddr) if xaddr else None
    url=xaddr if p and p.scheme in ("http","https") and p.hostname==ip else f"http://{ip}/onvif/device_service"
    x=soap(url,envelope("GetCapabilities",DEV,"<Category>All</Category>"),user,pwd)
    media=""
    for e in x.iter():
        if lname(e.tag)=="XAddr" and e.text:
            q=urlparse(e.text.strip())
            if q.scheme in ("http","https") and q.hostname==ip: media=e.text.strip(); break
    if not media:
        q=urlparse(url); media=f"{q.scheme}://{q.netloc}/onvif/media_service"
    px=soap(media,envelope("GetProfiles",MED),user,pwd); profiles=[]
    for e in px.iter():
        if lname(e.tag)=="Profiles" and e.attrib.get("token"):
            profiles.append({"token":e.attrib["token"],"name":txt(e,"Name") or f"Profile {len(profiles)+1}"})
    if not profiles: raise RuntimeError("No ONVIF media profiles returned.")
    did=str(uuid.uuid4()); DEVICES[did]={"ip":ip,"user":user,"pwd":pwd,"media":media,"profiles":profiles}
    return {"id":did,"ip":ip,"profiles":profiles[:64]}
def get_uri(d,token):
    t=token.replace("&","&amp;").replace('"',"&quot;")
    inner=f'<StreamSetup><Stream>RTP-Unicast</Stream><Transport><Protocol>RTSP</Protocol></Transport></StreamSetup><ProfileToken>{t}</ProfileToken>'
    x=soap(d["media"],envelope("GetStreamUri",MED,inner),d["user"],d["pwd"]); uri=txt(x,"Uri")
    if not uri: raise RuntimeError("NVR returned no RTSP URI.")
    p=urlparse(uri)
    if p.scheme=="rtsp" and not p.username:
        netloc=quote(d["user"],safe="")+":"+quote(d["pwd"],safe="")+"@"+p.hostname
        if p.port: netloc+=":"+str(p.port)
        uri=urlunparse((p.scheme,netloc,p.path,p.params,p.query,p.fragment))
    return uri
@app.get("/")
def index(): return render_template("index.html")
@app.post("/api/discover")
def api_discover():
    try:return jsonify(ok=True,devices=discover())
    except Exception as e:return jsonify(ok=False,error=str(e)),500
@app.post("/api/connect")
def api_connect():
    j=request.get_json(force=True)
    try:return jsonify(ok=True,device=connect(j.get("ip","").strip(),j.get("username",""),j.get("password",""),j.get("xaddr","").strip()))
    except Exception as e:return jsonify(ok=False,error=str(e)),400
@app.post("/api/stream")
def api_stream():
    j=request.get_json(force=True); d=DEVICES.get(j.get("device_id")); token=j.get("profile_token","")
    if not d:return jsonify(ok=False,error="Reconnect to NVR; session expired."),400
    if not any(p["token"]==token for p in d["profiles"]):return jsonify(ok=False,error="Invalid profile."),400
    if not shutil.which("ffmpeg"):return jsonify(ok=False,error="Install FFmpeg: pkg install ffmpeg -y"),400
    try:
        uri=get_uri(d,token); sid=str(uuid.uuid4()); folder=HLS/sid; folder.mkdir()
        playlist=folder/"live.m3u8"
        args=["ffmpeg","-nostdin","-loglevel","error","-rtsp_transport","tcp","-i",uri,"-an","-c:v","copy","-f","hls","-hls_time","2","-hls_list_size","5","-hls_flags","delete_segments+append_list",str(playlist)]
        proc=subprocess.Popen(args,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        STREAMS[sid]={"proc":proc,"folder":folder}
        return jsonify(ok=True,id=sid,playlist=f"/hls/{sid}/live.m3u8")
    except Exception as e:return jsonify(ok=False,error=str(e)),400
@app.get("/hls/<sid>/<path:name>")
def hls(sid,name):
    s=STREAMS.get(sid)
    if not s:return "Stream not found",404
    return send_from_directory(s["folder"],name,mimetype="application/vnd.apple.mpegurl" if name.endswith("m3u8") else "video/mp2t")
@app.post("/api/stop/<sid>")
def stop(sid):
    s=STREAMS.pop(sid,None)
    if s:
        try:s["proc"].terminate()
        except Exception:pass
    return jsonify(ok=True)
if __name__=="__main__":
    print("TECHHVEN dashboard: http://127.0.0.1:8765 (localhost only)")
    app.run(host="127.0.0.1",port=8765,debug=False,threaded=True)
